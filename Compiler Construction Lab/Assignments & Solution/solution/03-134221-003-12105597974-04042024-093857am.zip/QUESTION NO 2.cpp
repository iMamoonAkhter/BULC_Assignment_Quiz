file= "a.bash"

if [-s $file]
then 

 echo "file is exist"
 else
 echo "file is not exist"
 fi
 if [-r $file]
then
 echo "file is exist"
 else 
 echo  "file is not exist"
 fi
