#include<iostream>
#include<string>
using namespace std;
//assuming the share memory in c++
int segment= 0;

int main ()
{
    
    int pid;
    if(pid<0)
    {
        cout <<"ERROR"<< endl;
    }
    else if (pid==0)
    {
        cout << "child is executed"<< endl;
    }
    else
    {
        cout << "parent is executed"<< endl;
    }
 // parent value 
 cout <<"parent value is "<< segment<< endl;
 //sharing memory 
 //first child
segment++;
// sleep(5); 
 cout << "updated value is"<< segment<< endl;
 //second child
 
 segment++;
//11sleep(5);
 cout << "updated value is"<< segment<< endl;
 if(segment >0)
 {
 cout << "parent is executed";
  }  return 0;
}
