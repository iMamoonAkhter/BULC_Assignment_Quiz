#include<iostream>
#include<string>
using namespace std;
string state[3]={"running","block","ready"};
string event[4]={"block","timeout","unblock","dispatch"};

void process(int x,int y)
{
    int j=0;
   for (int i=0;i<x;i++)
   {
       if(state[i]=="running"&&event[j]=="block")
       {
           cout <<"new state is blocked"<< endl;
           break;
       }
     
         if(state[i]=="running"&&event[j]=="timeout")
       {
           cout <<"new state is ready"<< endl;
           break;
       }
         if(state[i]=="blocked"&&event[j]=="unblock")
       {
           cout <<"new state is ready"<< endl;
           break;
       }
         if(state[i]=="ready"&&event[j]=="dispatch")
       {
           cout <<"new state is running"<<endl;
           break;
       }
       j++;
   }

}
int main ()
{
 int a , b;
 a=4;
 b=4;
 process(a,b);
    return 0;
}
